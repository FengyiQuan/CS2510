// edge
class Edge {
  GamePiece fromNode;
  GamePiece toNode;
  int weight;

  Edge(GamePiece fromNode, GamePiece toNode, int weight) {
    this.fromNode = fromNode;
    this.toNode = toNode;
    this.weight = weight;
  }

  // determine if this edge is top-down pattern
  boolean isTopDown() {
    return this.fromNode.row + 1 == this.toNode.row && this.fromNode.col == this.toNode.col;
  }

  // determine if this edge is left-right pattern
  boolean isLeftRight() {
    return this.fromNode.row == this.toNode.row && this.fromNode.col + 1 == this.toNode.col;
  }
}