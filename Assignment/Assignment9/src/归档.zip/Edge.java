import java.util.ArrayList;
import tester.*;
import javalib.impworld.*;
import java.awt.Color;
import javalib.worldimages.*;

class Edge {
  GamePiece fromNode;
  GamePiece toNode;
  int weight;
}